# 📊 Task-1: Power BI Sales Dashboard Solution

This repository contains the solution for **Task-1** of the internship —  
**Developing a Power BI Dashboard showing sales trends, top products, and regional performance using sample data.**

---

## 📂 Repository Contents

```
data/
 ├── sales.csv
 ├── products.csv
 └── regions.csv
dax_measures.txt
README.md
```

**File descriptions:**
- `data/sales.csv` — Sample sales fact table.
- `data/products.csv` — Product dimension table.
- `data/regions.csv` — Region dimension table.
- `dax_measures.txt` — DAX measures for KPIs, top products, and Date table.
- `README.md` — Instructions for building the dashboard.

---

## 🛠 Steps to Build the Dashboard in Power BI

1. **Import Data**
   - Open Power BI Desktop.
   - Get Data → Text/CSV → import all three CSV files.

2. **Model Relationships**
   - `Sales[ProductID]` → `Products[ProductID]`
   - `Sales[Region]` → `Regions[Region]`

3. **Create Date Table**
   - Use the DAX from `dax_measures.txt` to create a `Date` table.
   - Mark it as a Date table in Power BI.

4. **Add Measures**
   - Copy all measures from `dax_measures.txt` into Power BI.

5. **Build Visuals**
   - **Line Chart:** `Date[Date]` vs `[Total Sales]`
   - **Bar Chart:** `Products[Product]` vs `[Total Sales]` (Top 5 filter)
   - **Map:** `Regions[Country]` with `[Total Sales]`
   - **KPI Cards:** `[Total Sales]`, `[Total Profit]`, `[Profit Margin %]`
   - **Slicers:** `Date[Date]`, `Products[Category]`, `Regions[Region]`

6. **Format & Save**
   - Add colors, labels, and adjust formatting.
   - Save as **Task1_Sales_Dashboard.pbix**.

---

## 📸 Example Output (Screenshots)

> Replace these placeholders with your actual screenshots.

**1. Sales Trend Line Chart**  
![Sales Trend](screenshots/sales_trend.png)

**2. Top Products Bar Chart**  
![Top Products](screenshots/top_products.png)

**3. Regional Sales Map**  
![Regional Map](screenshots/regional_map.png)

**4. KPI Cards & Slicers**  
![KPIs and Slicers](screenshots/kpis_slicers.png)

---

## ✅ Deliverable

A `.pbix` file named **Task1_Sales_Dashboard.pbix** with:
- Interactive visuals for sales trends, top products, and regional performance.
- Working slicers for Date, Product Category, and Region.

---

## 📬 Submission

Upload your `.pbix` file along with this repository link as your internship submission.

---

**Author:** Your Name  
**Date:** YYYY-MM-DD  
**Internship:** CODTECH Power BI Internship